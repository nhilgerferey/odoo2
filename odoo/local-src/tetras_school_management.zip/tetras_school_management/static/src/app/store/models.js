/** @odoo-module */

export class Teacher {
}

export class Student {

}

export class Mark {

}
